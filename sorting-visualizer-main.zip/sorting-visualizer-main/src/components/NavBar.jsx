import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { sortingAlgorithms } from "../common/config";
import { useData } from "../common/store";
import shallow from "zustand/shallow";


//This function is typically used in the context of a tabbed interface, where each tab has a corresponding panel of content that is displayed when the tab is selected.
function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    "aria-controls": `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: "#dd99ff",
    boxShadow: '0px 0px 10px rgba(0, 0, 0, 2)',
  },
  title: {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#260033',
    marginTop:'5px',
    marginBottom: '5px',
    fontFamily: "Snap ITC",
    textAlign: 'center',
  },
}));

export function NavBar() {
  const classes = useStyles();
// The useData hook takes two arguments: a selector function and an optional equality function.
  const [algorithm, setAlgorithm] = useData(
    (state) => [state.algorithm, state.setAlgorithm],
    shallow
  );

  return (
    <div className={classes.root}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <h3 className={classes.title}>AlgoWise</h3>
      </div>
      <AppBar position="static" color="default">
        <Tabs
          value={algorithm}
          onChange={(event, id) => setAlgorithm(id)}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
        >
          {/* this is iterating over objects in sortingAlgorithms and creating a */}
          {sortingAlgorithms.map((algorithm) => (
            <Tab
              label={algorithm.title}
              {...a11yProps(0)}
              key={algorithm.title}
            />
          ))}
         
        </Tabs>
      </AppBar>
    </div>
  );
}
